
context("Setup")

Sys.unsetenv("RENV_TESTS_INITIALIZED")
renv_tests_init()
