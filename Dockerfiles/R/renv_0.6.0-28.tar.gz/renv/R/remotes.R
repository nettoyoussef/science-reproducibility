
# take a short-form remotes entry, and generate a package record
renv_remotes_parse <- function(entry) {

  # check for URLs
  if (grepl("^(?:file|https?)://", entry))
    return(renv_remotes_parse_url(entry))

  # check for paths to existing local files
  record <- catch(renv_remotes_parse_local(entry))
  if (!inherits(record, "error"))
    return(record)

  # handle errors (add a bit of extra context)
  error <- function(e) {
    fmt <- "failed to parse remote entry '%s'"
    prefix <- sprintf(fmt, entry)
    message <- paste(prefix, e$message, sep = " -- ")
    stop(simpleError(message = message, call = e$call))
  }

  # attempt the parse
  withCallingHandlers(
    renv_remotes_parse_impl(entry),
    error = error
  )

}

renv_remotes_parse_impl <- function(entry) {

  parsed <- renv_remotes_parse_entry(entry)
  switch(
    parsed$type,
    bitbucket = renv_remotes_parse_bitbucket(parsed),
    cran      = renv_remotes_parse_cran(parsed),
    gitlab    = renv_remotes_parse_gitlab(parsed),
    github    = renv_remotes_parse_github(parsed),
    stopf("unknown remote type '%s'", parsed$type %||% "<NA>")
  )

}

renv_remotes_parse_entry <- function(entry) {

  pattern <- paste0(
    "(?:([^:]+)::)?",   # optional leading type
    "([^/#@]+)",        # a username
    "(?:/([^@#]+))?",   # a repository
    "(?:#([^@#]+))?",   # optional hash (e.g. pull request)
    "(?:@([^@#]+))?"    # optional ref (e.g. branch or commit)
  )

  matches <- regexec(pattern, entry)
  strings <- regmatches(entry, matches)[[1]]
  if (empty(strings))
    stopf("failed to parse remote entry '%s'", entry)

  parsed <- list(
    entry = strings[[1]],
    type  = strings[[2]],
    user  = strings[[3]],
    repo  = strings[[4]],
    pull  = strings[[5]],
    ref   = strings[[6]]
  )

  # handle cran vs. github short-forms
  if (!nzchar(parsed$type)) {
    type <- if (nzchar(parsed$repo)) "github" else "cran"
    parsed$type <- type
  }

  parsed

}

renv_remotes_parse_bitbucket <- function(entry) {

  user <- entry$user
  repo <- entry$repo
  ref  <- entry$ref %""% "master"

  host <- renv_config("bitbucket.host", "api.bitbucket.org/2.0")
  fmt <- "https://%s/repositories/%s/%s/src/%s/DESCRIPTION"
  url <- sprintf(fmt, host, user, repo, ref)

  destfile <- renv_tempfile("renv-description-")
  download(url, destfile = destfile, quiet = TRUE)
  desc <- renv_dcf_read(destfile)

  list(
    Package        = desc$Package,
    Version        = desc$Version,
    Source         = "Bitbucket",
    RemoteUsername = user,
    RemoteRepo     = repo,
    RemoteRef      = ref,
    RemoteHost     = host
  )

}

renv_remotes_parse_cran <- function(entry) {

  package <- entry$user
  version <- entry$ref %""% "latest"

  if (identical(version, "latest"))
    return(renv_records_cran_latest(package))

  list(
    Package    = package,
    Version    = version,
    Source     = "CRAN",
    RemoteType = "standard",
    RemoteRef  = package,
    RemoteSha  = version
  )

}

renv_remotes_parse_github_sha_pull <- function(host, user, repo, pull) {

  fmt <- "https://%s/repos/%s/%s/pulls/%s"
  url <- sprintf(fmt, host, user, repo, pull)
  jsonfile <- renv_tempfile("ren-json-")
  download(url, destfile = jsonfile, quiet = TRUE)
  json <- renv_json_read(jsonfile)
  json$head$sha

}

renv_remotes_parse_github_sha_ref <- function(host, user, repo, ref) {

  fmt <- "https://%s/repos/%s/%s/commits/%s"
  url <- sprintf(fmt, host, user, repo, ref)
  headers <- c(Accept = "application/vnd.github.v2.sha")
  shafile <- renv_tempfile("renv-sha-")
  download(url, destfile = shafile, quiet = TRUE, headers = headers)
  sha <- readChar(shafile, file.info(shafile)$size, TRUE)

  # check for JSON response (in case our headers weren't sent)
  if (nchar(sha) > 40) {
    json <- renv_json_read(text = sha)
    sha <- json$sha
  }

  sha

}

renv_remotes_parse_github_description <- function(host, user, repo, sha) {

  # get the DESCRIPTION contents
  fmt <- "https://%s/repos/%s/%s/contents/DESCRIPTION?ref=%s"
  url <- sprintf(fmt, host, user, repo, sha)
  jsonfile <- renv_tempfile("renv-json-")
  download(url, destfile = jsonfile, quiet = TRUE)
  json <- renv_json_read(jsonfile)
  contents <- renv_base64_decode(json$content)

  # write to file and read back in
  descfile <- renv_tempfile("renv-description-")
  writeLines(contents, con = descfile)
  renv_dcf_read(descfile)

}

renv_remotes_parse_gitlab <- function(entry) {

  user <- entry$user
  repo <- entry$repo
  ref  <- entry$ref %""% "master"

  fmt <- "https://%s/api/v4/projects/%s/repository/files/DESCRIPTION/raw?ref=%s"
  host <- renv_config("gitlab.host", "gitlab.com")
  id <- paste(user, repo, sep = "%2F")
  url <- sprintf(fmt, host, id, ref)

  destfile <- renv_tempfile("renv-description-")
  download(url, destfile = destfile, quiet = TRUE)
  desc <- renv_json_read(destfile)

  list(
    Package        = desc$Package,
    Version        = desc$Version,
    Source         = "Gitlab",
    RemoteUsername = user,
    RemoteRepo     = repo,
    RemoteRef      = ref,
    RemoteHost     = host
  )

}

renv_remotes_parse_github <- function(entry) {

  user <- entry$user
  repo <- entry$repo
  pull <- entry$pull
  ref  <- entry$ref %""% "master"

  # TODO: configure GitHub host on a per-package or per-remote basis?
  host <- renv_config("github.host", "api.github.com")

  # resolve the sha associated with the ref / pull
  sha <- case(
    nzchar(pull) ~ renv_remotes_parse_github_sha_pull(host, user, repo, pull),
    nzchar(ref)  ~ renv_remotes_parse_github_sha_ref(host, user, repo, ref)
  )

  desc <- renv_remotes_parse_github_description(host, user, repo, sha)

  list(
    Package        = desc$Package,
    Version        = desc$Version,
    Source         = "GitHub",
    RemoteUsername = user,
    RemoteRepo     = repo,
    RemoteRef      = ref,
    RemoteSha      = sha,
    RemoteHost     = host
  )

}

renv_remotes_parse_url <- function(entry) {

  tempfile <- renv_tempfile("renv-url-")
  writeLines(entry, con = tempfile)
  hash <- tools::md5sum(tempfile)

  ext <- fileext(entry, default = ".tar.gz")
  name <- paste(hash, ext, sep = "")
  path <- renv_paths_source("url", name)

  ensure_parent_directory(path)
  download(entry, path)

  desc <- renv_description_read(path)

  list(
    Package   = desc$Package,
    Version   = desc$Version,
    Source    = "URL",
    Path      = path,
    RemoteUrl = entry
  )

}

renv_remotes_parse_local <- function(entry) {

  # check for existing path
  path <- normalizePath(entry, winslash = "/", mustWork = TRUE)

  # first, check for a common extension
  ext <- fileext(entry)
  if (ext %in% c(".tar.gz", ".tgz", ".zip"))
    return(renv_remotes_parse_local_impl(path))

  # otherwise, if this is the path to a package project, use the sources as-is
  if (renv_project_type(path) == "package")
    return(renv_remotes_parse_local_impl(path))

  stopf("there is no package at path '%s'", entry)

}

renv_remotes_parse_local_impl <- function(path) {

  desc <- renv_description_read(path)
  list(
    Package   = desc$Package,
    Version   = desc$Version,
    Source    = path,
    Cacheable = FALSE
  )

}
