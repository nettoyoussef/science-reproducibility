
#' @importFrom utils available.packages contrib.url download.file file.edit
#'   head install.packages installed.packages old.packages packageDescription
#'   packageVersion read.table remove.packages tail tar untar update.packages
#'   unzip URLencode zip
NULL
