
# given a project, check and see if anything looks out-of-order
# regarding its active virtual environment (if any)
renv_diagnose <- function(project) {

  # TODO

}
