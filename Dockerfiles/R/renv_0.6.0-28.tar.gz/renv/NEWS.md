
# renv 1.0.0 (UNDER DEVELOPMENT)

* Initial CRAN release.
